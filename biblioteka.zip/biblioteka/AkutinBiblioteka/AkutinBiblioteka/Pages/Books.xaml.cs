﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AkutinBiblioteka.Pages
{
    /// <summary>
    /// Логика взаимодействия для Books.xaml
    /// </summary>
    public partial class Books : Page
    {
        private List<Booksy> allItems;
        public Books()
        {
            InitializeComponent();
            allItems = DbConnect.prObj.Booksy.ToList();
        }

        private void TxbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            try
            {
                Dbooks.ItemsSource = DbConnect.prObj.Booksy.Where(x => x.Name.Contains(TxbSearch.Text)).Take(15).ToList();
                TxbRezult.Text = Dbooks.Items.Count + "/" + DbConnect.prObj.Booksy.Where(x => x.Name.Contains(TxbSearch.Text)).Count().ToString();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        private void CmbSort_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmbSort.SelectedIndex == 0)
            {
                List<Booksy> sortMaterials = allItems.OrderBy(x => x.Author).ToList();
                Dbooks.ItemsSource = sortMaterials;
            }
            else if (CmbSort.SelectedIndex == 1)
            {
                List<Booksy> sortMaterials = allItems.OrderBy(x => x.Name).ToList();
                Dbooks.ItemsSource = sortMaterials;
            }
            else if (CmbSort.SelectedIndex == 2)
            {
                List<Booksy> sortMaterials = allItems.OrderBy(x => x.Yearofpublication).ToList();
                Dbooks.ItemsSource = sortMaterials;
            }
            else if (CmbSort.SelectedIndex == 3)
            {
                List<Booksy> sortMaterials = allItems.OrderBy(x => x.Publishinghouse).ToList();
                Dbooks.ItemsSource = sortMaterials;
            }
            else if (CmbSort.SelectedIndex == 4)
            {
                List<Booksy> sortMaterials = allItems.OrderByDescending(x => x.Volume).ToList();
                Dbooks.ItemsSource = sortMaterials;
            }
            else if (CmbSort.SelectedIndex == 5)
            {
                List<Booksy> sortMaterials = allItems.OrderByDescending(x => x.ISBN).ToList();
                Dbooks.ItemsSource = sortMaterials;
            }
            else if (CmbSort.SelectedIndex == 5)
            {
                List<Booksy> sortMaterials = allItems.OrderByDescending(x => x.Quantity).ToList();
                Dbooks.ItemsSource = sortMaterials;
            }
            else if (CmbSort.SelectedIndex == 5)
            {
                List<Booksy> sortMaterials = allItems.OrderByDescending(x => x.Vidano).ToList();
                Dbooks.ItemsSource = sortMaterials;
            }
            else if (CmbSort.SelectedIndex == 5)
            {
                List<Booksy> sortMaterials = allItems.OrderByDescending(x => x.Octatok).ToList();
                Dbooks.ItemsSource = sortMaterials;
            }
        }

        private void AddRequest_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new AddBooks(null));
        }

        private void MaterialList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void bookList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void BtnNazad_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new menu());
        }

        private void Dbooks_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                DbConnect.prObj.ChangeTracker.Entries().ToList().ForEach(x => x.Reload());
                Dbooks.ItemsSource = DbConnect.prObj.Booksy.ToList();
            }
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            {
                NavigationService.Navigate(new AddBooks((sender as Button).DataContext as Booksy));
            }
        }

        private void BtnEdit_Click1(object sender, RoutedEventArgs e)
        {
            var SotrForRemoving = Dbooks.SelectedItems.Cast<Booksy>().ToList();
            try
            {
                DbConnect.prObj.Booksy.RemoveRange(SotrForRemoving);
                DbConnect.prObj.SaveChanges();
                MessageBox.Show("Данные удалены.");

                Dbooks.ItemsSource = DbConnect.prObj.Booksy.ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Подтвердите удаление " + ex.Message.ToString(),
                "Уведомление",
                MessageBoxButton.OK, 
                MessageBoxImage.Warning); ;

            }
        }
    }
}
