﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AkutinBiblioteka.Pages
{
    /// <summary>
    /// Логика взаимодействия для Cpicokreaders.xaml
    /// </summary>
    public partial class Cpicokreaders : Page
    {
        private List<Readers> allItems;
        public Cpicokreaders()
        {
            InitializeComponent();
            allItems = DbConnect.prObj.Readers.ToList();
        }

        private void Addreaders_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new readers(null));
        }

        private void CmbSort_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmbSort.SelectedIndex == 0)
            {
                List<Readers> sortMaterials = allItems.OrderBy(x => x.Fio).ToList();
                Dcpicok.ItemsSource = sortMaterials;
            }
            else if (CmbSort.SelectedIndex == 1)
            {
                List<Readers> sortMaterials = allItems.OrderBy(x => x.Phone).ToList();
                Dcpicok.ItemsSource = sortMaterials;
            }
            else if (CmbSort.SelectedIndex == 2)
            {
                List<Readers> sortMaterials = allItems.OrderBy(x => x.Role).ToList();
                Dcpicok.ItemsSource = sortMaterials;
            }
            else if (CmbSort.SelectedIndex == 3)
            {
                List<Readers> sortMaterials = allItems.OrderBy(x => x.Class).ToList();
                Dcpicok.ItemsSource = sortMaterials;
            }
        }

        private void TxbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            try
            {
                Dcpicok.ItemsSource = DbConnect.prObj.Readers.Where(x => x.Fio.Contains(TxbSearch.Text)).Take(15).ToList();
                TxbRezult.Text = Dcpicok.Items.Count + "/" + DbConnect.prObj.Readers.Where(x => x.Fio.Contains(TxbSearch.Text)).Count().ToString();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        private void readersList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void Page_Loaded_1(object sender, RoutedEventArgs e)
        {

        }

        private void BtnNazad_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.GoBack();
        }

        private void Addextradition_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new readers(null));
        }

        private void Dcpicok_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                DbConnect.prObj.ChangeTracker.Entries().ToList().ForEach(x => x.Reload());
                Dcpicok.ItemsSource = DbConnect.prObj.Readers.ToList();
            }
        }

        private void BtnEdit_Click1(object sender, RoutedEventArgs e)
        {
            var SotrForRemoving = Dcpicok.SelectedItems.Cast<Readers>().ToList();
            try
            {
                DbConnect.prObj.Readers.RemoveRange(SotrForRemoving);
                DbConnect.prObj.SaveChanges();
                MessageBox.Show("Данные удалены.");

                Dcpicok.ItemsSource = DbConnect.prObj.Readers.ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Подтвердите удаление " + ex.Message.ToString(),
                "Уведомление",
                MessageBoxButton.OK,
                MessageBoxImage.Warning); ;

            }
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            {
                NavigationService.Navigate(new readers((sender as Button).DataContext as Readers));
            }
        }
    }
}
