﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AkutinBiblioteka.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddBooks.xaml
    /// </summary>
    public partial class AddBooks : Page
    {
        private Booksy bookObj = new Booksy();
        public AddBooks(Booksy selectedBooks)
        {
            InitializeComponent();
            if (selectedBooks != null)
            bookObj = selectedBooks;

            DataContext = bookObj;

        }

        private void Btn_Create_Click(object sender, RoutedEventArgs e)
        {

            Booksy bookObj = new Booksy()
            {
                Name = Txb_Name.Text,
                Author = Txb_Author.Text,
                Yearofpublication = Convert.ToInt32(Txb_Yearofpublication.Text),
                Volume = Convert.ToInt32(Txb_Volume.Text),
                ISBN = Txb_ISBN.Text,
                Publishinghouse = Txb_Publishinghouse.Text,
                Description = Txb_Description.Text,
                Quantity = Convert.ToInt32(Txb_Quantity.Text),
                Annotation = Txb_Annotation.Text,
             };

            DbConnect.prObj.Booksy.Add(bookObj);
            DbConnect.prObj.SaveChanges();

            MessageBox.Show("Книга добавлена!",
                "Уведомление",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }

        private void Txb_Volume_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    

        private void BtnNazad_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.GoBack();
        }

        private void Txb_Name_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
