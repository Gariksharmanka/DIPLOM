﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AkutinBiblioteka.Pages
{
    /// <summary>
    /// Логика взаимодействия для extradition.xaml
    /// </summary>
    public partial class extradition : Page
    {
        private List<ExtraditionTab> allItems;
        public extradition()
        {
            InitializeComponent();
            allItems = DbConnect.prObj.ExtraditionTab.ToList();
        }

        private void Addreaders_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new AddRequest(null));
        }

        private void TxbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            try
            {
                Dextradition.ItemsSource = DbConnect.prObj.Booksy.Where(x => x.Name.Contains(TxbSearch.Text)).Take(15).ToList();
                TxbRezult.Text = Dextradition.Items.Count + "/" + DbConnect.prObj.Booksy.Where(x => x.Name.Contains(TxbSearch.Text)).Count().ToString();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        private void extraditionList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void CmbSort_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmbSort.SelectedIndex == 0)
            {
                List<ExtraditionTab> sortMaterials = allItems.OrderBy(x => x.Fio_id).ToList();
                Dextradition.ItemsSource = sortMaterials;
            }
            else if (CmbSort.SelectedIndex == 1)
            {
                List<ExtraditionTab> sortMaterials = allItems.OrderBy(x => x.Book_id).ToList();
                Dextradition.ItemsSource = sortMaterials;
            }
            else if (CmbSort.SelectedIndex == 2)
            {
                List<ExtraditionTab> sortMaterials = allItems.OrderBy(x => x.Refund).ToList();
                Dextradition.ItemsSource = sortMaterials;
            }
            else if (CmbSort.SelectedIndex == 3)
            {
                List<ExtraditionTab> sortMaterials = allItems.OrderBy(x => x.DataVidachi).ToList();
                Dextradition.ItemsSource = sortMaterials;
            }
            else if (CmbSort.SelectedIndex == 3)
            {
                List<ExtraditionTab> sortMaterials = allItems.OrderBy(x => x.DataVos).ToList();
                Dextradition.ItemsSource = sortMaterials;
            }
        }

        private void BtnNazad_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.GoBack();
        }

        private void Addextradition_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new AddRequest(null));
        }

        private void Dextradition_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                DbConnect.prObj.ChangeTracker.Entries().ToList().ForEach(x => x.Reload());
                Dextradition.ItemsSource = DbConnect.prObj.ExtraditionTab.ToList();
            }
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            
             {
                NavigationService.Navigate(new AddRequest((sender as Button).DataContext as ExtraditionTab));
             }
            
        }

        private void BtnEdit_Click1(object sender, RoutedEventArgs e)
        {
            var SotrForRemoving = Dextradition.SelectedItems.Cast<ExtraditionTab>().ToList();
            try
            {
                DbConnect.prObj.ExtraditionTab.RemoveRange(SotrForRemoving);
                DbConnect.prObj.SaveChanges();
                MessageBox.Show("Данные удалены.");

                Dextradition.ItemsSource = DbConnect.prObj.ExtraditionTab.ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Подтвердите удаление " + ex.Message.ToString(),
                "Уведомление",
                MessageBoxButton.OK,
                MessageBoxImage.Warning); ;

            }
        }
    }
}
