﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AkutinBiblioteka.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddRequest.xaml
    /// </summary>
    public partial class AddRequest : Page
    {
        private ExtraditionTab extraditionObj = new ExtraditionTab();
        public AddRequest(ExtraditionTab selectedextradition)
        {
            InitializeComponent();
            if (selectedextradition != null)
            extraditionObj = selectedextradition;

            DataContext = extraditionObj;
        }

        private void Btn_Create_Click(object sender, RoutedEventArgs e)
        {

            ExtraditionTab extraditionObj = new ExtraditionTab()
            {
              Fio_id = Convert.ToInt32(Txb_Fioid.Text),
              Book_id = Convert.ToInt32(Txb_Bookid.Text),
              DataVidachi = Convert.ToDateTime(Txb_DataVidachi1.Text),
              Refund = Convert.ToInt32(Txb_Refund.Text),
              DataVos = Convert.ToDateTime(Txb_DataVos1.Text),
            };
            DbConnect.prObj.ExtraditionTab.Add(extraditionObj);
            DbConnect.prObj.SaveChanges();

            MessageBox.Show("Выдача добавлена!",
                "Уведомление",
                MessageBoxButton.OK,
                MessageBoxImage.Information);

        }

        private void BtnNazad_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.GoBack();
        }
    }
}
