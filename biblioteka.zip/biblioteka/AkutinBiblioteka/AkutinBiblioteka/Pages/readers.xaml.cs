﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AkutinBiblioteka.Pages
{
    /// <summary>
    /// Логика взаимодействия для readers.xaml
    /// </summary>
    public partial class readers : Page
    {
        private Readers readersObj = new Readers();
        public readers(Readers selectedreaders)
        {
            InitializeComponent();
            if (selectedreaders != null)
            readersObj = selectedreaders;

            DataContext = readersObj;
        }

        private void CmbSort_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void BtnNazad_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new menu());
        }

        private void Btnsafe_Click(object sender, RoutedEventArgs e)
        {

            Readers readersObj = new Readers()
            {
                Fio = Txb_Fio.Text,
                Class = Txb_Class.Text,
                Phone = Txb_Phone.Text,
                Role = CmbRole.Text,

            };

            DbConnect.prObj.Readers.Add(readersObj);
            DbConnect.prObj.SaveChanges();

            MessageBox.Show("Читатель добавлен!",
                "Уведомление",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }
    private void BtnNazad1_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.GoBack();
        }
    }
}
